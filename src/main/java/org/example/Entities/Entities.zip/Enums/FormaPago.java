package org.example.Entities.Enums;

public enum FormaPago {
    EFECTIVO,
    MERCADOPAGO
}
