package org.example.Entities.Enums;

public enum TipoPromocion {
    HAPPYHOUR,
    PROMOCION1,
}
