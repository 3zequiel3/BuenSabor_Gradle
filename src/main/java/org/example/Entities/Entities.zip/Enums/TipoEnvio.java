package org.example.Entities.Enums;

public enum TipoEnvio {
    DELIBERY,
    TAKEAWAY
}
